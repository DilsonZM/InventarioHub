# AGENTS.md

## Commands

```bash
cd backend && npm install
npm start          # production — http://localhost:3000
npm run dev        # watch mode (node --watch, requires Node 18+)
```

No test, lint, typecheck, or build step exists. No frontend build — Tailwind and Chart.js load via CDN.

## Architecture

Single Express server (`backend/server.js`) serves both the API and the frontend as static files from `../frontend`. There is no separate frontend dev server.

- **Persistence**: `backend/db.json` — read/written directly by `backend/models/db.js`. Mutations (product CRUD, sales) modify this file on disk. Reset by restoring from git.
- **Auth**: JWT in `Authorization: Bearer <token>`. Passwords are SHA-256 hex digests (not bcrypt). Middleware in `backend/middleware/auth.js`.
- **Roles**: `admin` (full CRUD on products) and `vendedor` (read products, create sales). Product create/update/delete routes use `adminOnly` middleware.
- **Frontend**: Vanilla JS (no framework). Single-page app with hash routing (`#dashboard`, `#inventory`, `#sales`). All JS files are plain scripts (not ES modules) loaded via `<script>` tags. Global `API` object in `js/api.js` wraps fetch calls.
- **Styling**: Tailwind CSS via CDN (`<script src="https://cdn.tailwindcss.com">`). Font: Inter via Google Fonts.

## Demo credentials

| User | Password | Role |
|------|----------|------|
| `admin` | `admin123` | admin |
| `vendedor1` | `admin123` | vendedor |

## Conventions

- API responses: `{ success: boolean, data?: any, message?: string }`
- API prefix: `/api` — auth (`/api/auth`), products (`/api/products`), sales (`/api/sales`), stats (`/api/stats`)
- Product delete is soft-delete (sets `active: false`)
- Sale creation atomically decrements stock; rejects if any item exceeds available stock
- UI language is Spanish; keep user-facing strings in Spanish
