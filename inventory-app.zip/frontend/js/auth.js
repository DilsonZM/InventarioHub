document.addEventListener('DOMContentLoaded', () => {
  if (API.isAuthenticated()) {
    window.location.href = '/index.html';
    return;
  }

  const tabLogin = document.getElementById('tabLogin');
  const tabRegister = document.getElementById('tabRegister');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  function switchTab(tab) {
    if (tab === 'login') {
      tabLogin.classList.add('bg-blue-600', 'text-white');
      tabLogin.classList.remove('text-slate-400');
      tabRegister.classList.remove('bg-blue-600', 'text-white');
      tabRegister.classList.add('text-slate-400');
      loginForm.classList.remove('hidden');
      registerForm.classList.add('hidden');
    } else {
      tabRegister.classList.add('bg-blue-600', 'text-white');
      tabRegister.classList.remove('text-slate-400');
      tabLogin.classList.remove('bg-blue-600', 'text-white');
      tabLogin.classList.add('text-slate-400');
      registerForm.classList.remove('hidden');
      loginForm.classList.add('hidden');
    }
    document.querySelectorAll('[id$="Error"]').forEach(el => el.classList.add('hidden'));
  }

  tabLogin.addEventListener('click', () => switchTab('login'));
  tabRegister.addEventListener('click', () => switchTab('register'));

  function setLoading(btn, loading) {
    btn.disabled = loading;
    const spinner = btn.querySelector('[data-spinner]');
    if (spinner) spinner.classList.toggle('hidden', !loading);
  }

  function showError(containerId, message) {
    const el = document.getElementById(containerId);
    el.classList.remove('hidden');
    el.querySelector('p').textContent = message;
  }

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const btn = document.getElementById('loginBtn');

    if (!username || !password) {
      showError('loginError', 'Completa todos los campos');
      return;
    }

    setLoading(btn, true);
    try {
      const res = await API.auth.login(username, password);
      API.setToken(res.data.token);
      API.setUser(res.data.user);
      window.location.href = '/index.html';
    } catch (err) {
      showError('loginError', err.message);
    } finally {
      setLoading(btn, false);
    }
  });

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('regUsername').value.trim();
    const password = document.getElementById('regPassword').value;
    const role = document.getElementById('regRole').value;
    const btn = document.getElementById('registerBtn');

    if (!username || !password) {
      showError('registerError', 'Completa todos los campos');
      return;
    }

    setLoading(btn, true);
    try {
      const res = await API.auth.register(username, password, role);
      API.setToken(res.data.token);
      API.setUser(res.data.user);
      window.location.href = '/index.html';
    } catch (err) {
      showError('registerError', err.message);
    } finally {
      setLoading(btn, false);
    }
  });
});
